
export const BASE_URL = 'https://s5a9piweb01.sylvamo.com/piwebapi'
export const PM6_WEBID = 'F1Em_v7LqlZaAkW49B2ZP1gZGgHzSUib6k7hGOrK3Ua0z4NgTU9HSSBHVUFDVVxURUNOT0xPR0lBXE1BQ0hJTkVTVEFURVxQTTZcU1RBVEU'
// export const AF_PATH = '\\\\Mogi Guacu\\PythonSandBox\\'